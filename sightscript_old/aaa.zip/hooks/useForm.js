import { useCallback, useEffect, useState } from "react";
import default_callback from "../bssl/default_callback";
import Request from "../bssl/Request";

/**
 * @example const [formstate, setFormstate, handleChange, submit] = useForm([{ name: "create", path: "stories/new", redirect: "/some/url" }])
 */

/**
 * @typedef {Object} Path
 * @property {string} name
 * @property {string} path
 * @property {string | null} redirect
 * @param {Path[]} paths 
 * @returns 
 */
export default function useForm(paths, default_state) {
  const [formstate, setFormstate] = useState(default_state || new Object());

  const handleChange = useCallback(function (e) {
    console.log(e.target);
    const inp = document.getElementById(e.target.name);
    if(e.target.inp && e.target.inp.type === "boolean") {
      if(inp.checked === true) {
        inp.checked = false;
        document.getElementById(e.target.name + "__ui").innerHTML = "";
      } else {
        inp.checked = true;
        document.getElementById(e.target.name + "__ui").innerHTML = "&#x2714;";
      }
    } else {
      inp.value = e.target.value;
    }
 
    return;
    if(!this) {
      setFormstate(pr => {return {...pr, [e.target.name]: e.target.value}});
      return;
    }
    const { type, name, value } = this;
    switch (type) {
      case "checked":
        console.log( type, name, value, e.target.name )
        setFormstate(pr => { return { ...pr, [e.target.name]: e.target.value } });
        break;

      case "costum": 
        setFormstate(pr => { return { ...pr, [name]: value } });
      default:
        break;
    }
  })


  return [formstate, setFormstate, handleChange];
}
