import { useState } from "react";



const Boolean = ({ inp, formstate, handleChange }) => {
  const [open, setOpen] = useState(false);

  return (
    <div className="w-100 p-relative" style={{margin: "var(--m1) 0px"}}>
        <input
            id={inp.name}
            style={{display: "none"}}
            value={false}
            type={"checkbox"}
            name={inp.name}
            placeholder="Aa.."
        />
        <label>
            {inp.label}
        </label>
        <div className="boolean-input" id={inp.name + "__ui"} onClick={e => handleChange({target: {
            name: inp.name, inp: inp, value: document.getElementById(inp.name).value
        }})}>&#x2714;</div>
    </div>
  );
};
export default Boolean;
