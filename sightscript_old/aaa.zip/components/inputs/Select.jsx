import { useState } from "react";



const SelectInput = ({ inp, formstate, handleChange }) => {
  const [open, setOpen] = useState(false);

  return (
    <div className="w-100 p-relative" style={{margin: "var(--m1) 0px"}}>
      <div className="select-input-wrapper d-flex j-cont-center al-items-center p-relative" style={{zIndex: 2}}>
        <input
            id={inp.name}
            style={{margin: "0px"}}
            type={inp.inp_type}
            name={inp.name}
            value={formstate[inp.name]}
            placeholder="Aa.."
        />
        <button icon="t" style={{
            paddingTop: "6.9px", margin: 0, position: "absolute", right: 14, top: 0, bottom: 0, marginTop: "auto", marginBottom: "auto", border: "none", height: "69%"
            }} onClick={() => setOpen(pr => !pr)}>
            {open ? <div>&#x2716;</div> : <div>&#8675;</div>}
        </button>
      </div>
      {
        open && (
            <div className="select-options-wrapper d-flex f-column j-cont-start al-items-start p2" style={{zIndex: 14}}>
                {inp.options && inp.options.map((o, i) => {
                    return (
                        <span 
                            is-select={o.value === formstate[o.name] ? "true" : "false"} 
                            onClick={() => handleChange({ target: { name: inp.name, inp: inp, value: o.value } })}>
                                {o.label}
                        </span>
                    )
                })}
            </div>
        )
      }
      {
        open && (
            <div className="fixed-bg" onClick={() => setOpen(false)}></div>
        )
      }
    </div>
  );
};
export default SelectInput;
