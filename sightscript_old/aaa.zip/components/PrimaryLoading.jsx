

const PrimaryLoading = () => {
    return (
        <p>loading</p>
    );
}
 
export default PrimaryLoading;